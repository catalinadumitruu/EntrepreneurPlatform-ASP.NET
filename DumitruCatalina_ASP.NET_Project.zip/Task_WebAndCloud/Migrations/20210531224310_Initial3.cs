﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace Task_WebAndCloud.Migrations
{
    public partial class Initial3 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
