﻿using System;

namespace Task_WebAndCloud.Areas.Identity.Pages.Account
{
    internal class ClientScriptManager
    {
        internal void RegisterClientScriptBlock(Type cstype, string s, string v)
        {
            throw new NotImplementedException();
        }
    }
}